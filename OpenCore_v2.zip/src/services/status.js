export default function status() {
  return {
    ok: true,
    version: '2.0',
    uptime: process.uptime(),
    timestamp: Date.now()
  };
}