export default function random() {
  return {
    number: Math.floor(Math.random() * 1000),
    timestamp: Date.now()
  };
}