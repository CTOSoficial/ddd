import { Router } from 'express';
import status from '../services/status.js';
import random from '../services/random.js';

const router = Router();

router.get('/status', (req, res) => {
  res.json(status());
});

router.get('/random', (req, res) => {
  res.json(random());
});

export default router;