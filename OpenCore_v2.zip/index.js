import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import apiRoutes from './src/routes/api.js';

const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(morgan('dev'));

app.use('/api', apiRoutes);

app.get('/', (req, res) => {
  res.json({ message: 'OpenCore API v2 funcionando correctamente 🚀' });
});

app.listen(3000, () => console.log('🔵 OpenCore API v2 corriendo en http://localhost:3000'));
